package analizator.generated;
public enum State{
S_pocetno,S_komentar,S_jednolinijskiKomentar,S_string;
}