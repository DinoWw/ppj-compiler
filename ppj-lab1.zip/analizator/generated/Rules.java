package analizator.generated;
import analizator.generated.State;
import analizator.generated.LexClass;
import analizator.structures.Rule;
import analizator.structures.Automat;
import java.util.EnumMap;
import java.util.Map;
public class Rules{
public static Map<State, Rule[]> getRules(){
Map<State, Rule[]> tmp = new EnumMap<>(State.class);tmp.put( State.S_komentar, new Rule[] {new Rule( State.S_komentar, new Automat("\\*/"), null, false, State.S_pocetno, -1 ),
new Rule( State.S_komentar, new Automat("\\n"), null, true, null, -1 ),
new Rule( State.S_komentar, new Automat("(\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\t|\\n|\\_|!|\"|#|%|&|\'|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)"), null, false, null, -1 ),
});
tmp.put( State.S_jednolinijskiKomentar, new Rule[] {new Rule( State.S_jednolinijskiKomentar, new Automat("\\n"), null, true, State.S_pocetno, -1 ),
new Rule( State.S_jednolinijskiKomentar, new Automat("(\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\t|\\n|\\_|!|\"|#|%|&|\'|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)"), null, false, null, -1 ),
});
tmp.put( State.S_string, new Rule[] {new Rule( State.S_string, new Automat("\"((\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\t|\\_|!|#|%|&|\'|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)|\\\\\")*\""), LexClass.NIZ_ZNAKOVA, false, State.S_pocetno, -1 ),
});
tmp.put( State.S_pocetno, new Rule[] {new Rule( State.S_pocetno, new Automat("\\t|\\_"), null, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\n"), null, true, null, -1 ),
new Rule( State.S_pocetno, new Automat("//"), null, false, State.S_jednolinijskiKomentar, -1 ),
new Rule( State.S_pocetno, new Automat("/\\*"), null, false, State.S_komentar, -1 ),
new Rule( State.S_pocetno, new Automat("\""), null, false, State.S_string, 0 ),
new Rule( State.S_pocetno, new Automat("break"), LexClass.KR_BREAK, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("char"), LexClass.KR_CHAR, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("const"), LexClass.KR_CONST, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("continue"), LexClass.KR_CONTINUE, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("else"), LexClass.KR_ELSE, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("float"), LexClass.KR_FLOAT, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("for"), LexClass.KR_FOR, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("if"), LexClass.KR_IF, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("int"), LexClass.KR_INT, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("return"), LexClass.KR_RETURN, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("void"), LexClass.KR_VOID, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("while"), LexClass.KR_WHILE, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("(_|(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z))(_|(a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z)|(0|1|2|3|4|5|6|7|8|9))*"), LexClass.IDN, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("(0|1|2|3|4|5|6|7|8|9)(0|1|2|3|4|5|6|7|8|9)*"), LexClass.BROJ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("0(X|x)((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)((0|1|2|3|4|5|6|7|8|9)|a|b|c|d|e|f|A|B|C|D|E|F)*"), LexClass.BROJ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\'(\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\_|!|\"|#|%|&|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)\'"), LexClass.ZNAK, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\'\\\\(\\(|\\)|\\{|\\}|\\||\\*|\\\\|\\$|\\_|!|\"|#|%|&|\'|+|,|-|.|/|0|1|2|3|4|5|6|7|8|9|:|;|<|=|>|?|@|A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z|[|]|^|_|`|a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|~)\'"), LexClass.ZNAK, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("++"), LexClass.OP_INC, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("--"), LexClass.OP_DEC, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("+"), LexClass.PLUS, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("-"), LexClass.MINUS, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\*"), LexClass.OP_PUTA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("/"), LexClass.OP_DIJELI, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("%"), LexClass.OP_MOD, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("="), LexClass.OP_PRIDRUZI, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("<"), LexClass.OP_LT, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("<="), LexClass.OP_LTE, false, null, -1 ),
new Rule( State.S_pocetno, new Automat(">"), LexClass.OP_GT, false, null, -1 ),
new Rule( State.S_pocetno, new Automat(">="), LexClass.OP_GTE, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("=="), LexClass.OP_EQ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("!="), LexClass.OP_NEQ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("!"), LexClass.OP_NEG, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("~"), LexClass.OP_TILDA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("&&"), LexClass.OP_I, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\|\\|"), LexClass.OP_ILI, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("&"), LexClass.OP_BIN_I, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\|"), LexClass.OP_BIN_ILI, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("^"), LexClass.OP_BIN_XILI, false, null, -1 ),
new Rule( State.S_pocetno, new Automat(","), LexClass.ZAREZ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat(";"), LexClass.TOCKAZAREZ, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\("), LexClass.L_ZAGRADA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\)"), LexClass.D_ZAGRADA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\{"), LexClass.L_VIT_ZAGRADA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("\\}"), LexClass.D_VIT_ZAGRADA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("["), LexClass.L_UGL_ZAGRADA, false, null, -1 ),
new Rule( State.S_pocetno, new Automat("]"), LexClass.D_UGL_ZAGRADA, false, null, -1 ),
});
return tmp;
};
}